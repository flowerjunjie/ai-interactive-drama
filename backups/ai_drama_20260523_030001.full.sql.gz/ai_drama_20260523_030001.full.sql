-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: ai_video
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apscheduler_jobs`
--

DROP TABLE IF EXISTS `apscheduler_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apscheduler_jobs` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_run_time` double DEFAULT NULL,
  `job_state` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_apscheduler_jobs_next_run_time` (`next_run_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apscheduler_jobs`
--

LOCK TABLES `apscheduler_jobs` WRITE;
/*!40000 ALTER TABLE `apscheduler_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `apscheduler_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama`
--

DROP TABLE IF EXISTS `drama`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama` (
  `drama_id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `drama_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comic_drama',
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `sort` int NOT NULL DEFAULT '0',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `update_time` datetime DEFAULT NULL,
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签 JSON 或逗号分隔',
  `heat` int NOT NULL DEFAULT '0' COMMENT '热度',
  PRIMARY KEY (`drama_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短剧';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama`
--

LOCK TABLES `drama` WRITE;
/*!40000 ALTER TABLE `drama` DISABLE KEYS */;
INSERT INTO `drama` VALUES (1,'都市狂想','https://picsum.photos/seed/d1/400/600','都市青年意外获得读心术，在职场与情感中层层闯关','urban','published',10,'',NULL,'',NULL,NULL,'都市异能职场',8500),(2,'古风奇缘','https://picsum.photos/seed/d2/400/600','穿越古代成为王妃，宫廷权谋中寻找真爱','costume','published',9,'',NULL,'',NULL,NULL,'古风穿越宫斗',6200),(3,'浪漫满屋','https://picsum.photos/seed/d3/400/600','欢喜冤家合租一屋檐下，日久生情的爆笑爱情','romance','published',8,'',NULL,'',NULL,NULL,'甜宠合租都市',9100),(4,'时光穿越','https://picsum.photos/seed/d4/400/600','意外穿越到20年前，改写命运的奇幻之旅','fantasy','published',7,'',NULL,'',NULL,NULL,'穿越悬疑',7800),(5,'心跳职场','https://picsum.photos/seed/d5/400/600','职场新人逆袭，成长与爱情并行','urban','published',6,'',NULL,'',NULL,NULL,'职场成长',7300),(6,'星际恋歌','https://picsum.photos/seed/d6/400/600','跨越星系的爱情，宇宙级别的浪漫','sci_fi','published',5,'',NULL,'',NULL,NULL,'科幻星际',8600);
/*!40000 ALTER TABLE `drama` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_ad`
--

DROP TABLE IF EXISTS `drama_ad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_ad` (
  `ad_id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `media_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'image' COMMENT 'image/video',
  `media_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主素材',
  `image_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '兼容旧字段',
  `cover_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '视频封面',
  `link_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slot_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'feed',
  `weight` int NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `impression_count` bigint NOT NULL DEFAULT '0',
  `click_count` bigint NOT NULL DEFAULT '0',
  `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短剧广告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_ad`
--

LOCK TABLES `drama_ad` WRITE;
/*!40000 ALTER TABLE `drama_ad` DISABLE KEYS */;
INSERT INTO `drama_ad` VALUES (1,'热门新剧推荐','image',NULL,'https://picsum.photos/seed/ad1/400/225',NULL,NULL,'feed',1,NULL,NULL,0,0,'0',NULL),(2,'古风穿越剧','image',NULL,'https://picsum.photos/seed/ad2/400/225',NULL,NULL,'feed',2,NULL,NULL,0,0,'0',NULL),(3,'甜宠剧推荐','image',NULL,'https://picsum.photos/seed/ad3/400/225',NULL,NULL,'feed',3,NULL,NULL,0,0,'0',NULL);
/*!40000 ALTER TABLE `drama_ad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_app_user`
--

DROP TABLE IF EXISTS `drama_app_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_app_user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '登录账号',
  `nick_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '昵称',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码hash',
  `avatar` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '头像',
  `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '0正常1停用',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uk_drama_app_user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短剧 C 端用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_app_user`
--

LOCK TABLES `drama_app_user` WRITE;
/*!40000 ALTER TABLE `drama_app_user` DISABLE KEYS */;
INSERT INTO `drama_app_user` VALUES (1,'testuser','testuser','$2b$12$eDgZgn1RwRj.H/kqd7K2H.d4UGErodUgq83tiQFm3JNhRawdWTGhO','','0','2026-05-22 01:26:58','2026-05-22 01:26:58');
/*!40000 ALTER TABLE `drama_app_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_comment`
--

DROP TABLE IF EXISTS `drama_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_comment` (
  `comment_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `node_id` bigint DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `idx_dc_drama` (`drama_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_comment`
--

LOCK TABLES `drama_comment` WRITE;
/*!40000 ALTER TABLE `drama_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_upload_file`
--

DROP TABLE IF EXISTS `drama_upload_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_upload_file` (
  `file_id` bigint NOT NULL AUTO_INCREMENT,
  `object_key` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bucket` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size_bytes` bigint DEFAULT NULL,
  `drama_id` bigint DEFAULT NULL,
  `node_id` bigint DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='上传文件记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_upload_file`
--

LOCK TABLES `drama_upload_file` WRITE;
/*!40000 ALTER TABLE `drama_upload_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_upload_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_user_choice_log`
--

DROP TABLE IF EXISTS `drama_user_choice_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_user_choice_log` (
  `log_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `from_node_id` bigint DEFAULT NULL,
  `choice_id` bigint NOT NULL,
  `to_node_id` bigint NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分支选择记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_user_choice_log`
--

LOCK TABLES `drama_user_choice_log` WRITE;
/*!40000 ALTER TABLE `drama_user_choice_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_user_choice_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_user_favorite`
--

DROP TABLE IF EXISTS `drama_user_favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_user_favorite` (
  `fav_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`fav_id`),
  UNIQUE KEY `uq_drama_fav_user_drama` (`app_user_id`,`drama_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='收藏';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_user_favorite`
--

LOCK TABLES `drama_user_favorite` WRITE;
/*!40000 ALTER TABLE `drama_user_favorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_user_favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_user_like`
--

DROP TABLE IF EXISTS `drama_user_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_user_like` (
  `like_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `target_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`like_id`),
  UNIQUE KEY `uq_drama_like_target` (`app_user_id`,`target_type`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='点赞';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_user_like`
--

LOCK TABLES `drama_user_like` WRITE;
/*!40000 ALTER TABLE `drama_user_like` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_user_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_user_watch_history`
--

DROP TABLE IF EXISTS `drama_user_watch_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_user_watch_history` (
  `history_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `node_id` bigint DEFAULT NULL,
  `progress_sec` int NOT NULL DEFAULT '0',
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`history_id`),
  UNIQUE KEY `uq_drama_watch_user_drama` (`app_user_id`,`drama_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='观看进度';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_user_watch_history`
--

LOCK TABLES `drama_user_watch_history` WRITE;
/*!40000 ALTER TABLE `drama_user_watch_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_user_watch_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_video_choice`
--

DROP TABLE IF EXISTS `drama_video_choice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_video_choice` (
  `choice_id` bigint NOT NULL AUTO_INCREMENT,
  `node_id` bigint NOT NULL,
  `choice_code` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '选项编码 A/B/C',
  `label` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_node_id` bigint NOT NULL,
  `sort` int NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`choice_id`),
  KEY `idx_dvc_node` (`node_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分支选项';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_video_choice`
--

LOCK TABLES `drama_video_choice` WRITE;
/*!40000 ALTER TABLE `drama_video_choice` DISABLE KEYS */;
INSERT INTO `drama_video_choice` VALUES (1,2,NULL,'A: 接受安排',3,1,NULL),(2,2,NULL,'B: 自主创业',4,2,NULL),(3,3,NULL,'A: 留下来',4,1,NULL),(4,3,NULL,'B: 跳槽',4,2,NULL),(5,6,NULL,'A: 入宫选秀',7,1,NULL),(6,6,NULL,'B: 出宫创业',8,2,NULL),(7,7,NULL,'A: 争夺后位',8,1,NULL),(8,7,NULL,'B: 归隐山林',8,2,NULL),(9,10,NULL,'A: 表白',11,1,NULL),(10,10,NULL,'B: 继续暗恋',11,2,NULL),(11,13,NULL,'A: 改变历史',14,1,NULL),(12,13,NULL,'B: 顺其自然',14,2,NULL),(13,16,NULL,'A: 努力表现',17,1,NULL),(14,16,NULL,'B: 另寻高就',17,2,NULL),(15,19,NULL,'A: 留在舰队',20,1,NULL),(16,19,NULL,'B: 寻找真相',21,2,NULL),(17,20,NULL,'A: 接受使命',21,1,NULL),(18,20,NULL,'B: 回到过去',21,2,NULL);
/*!40000 ALTER TABLE `drama_video_choice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_video_node`
--

DROP TABLE IF EXISTS `drama_video_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_video_node` (
  `node_id` bigint NOT NULL AUTO_INCREMENT,
  `drama_id` bigint NOT NULL,
  `parent_node_id` bigint DEFAULT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tos_key` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'TOS 对象键',
  `duration_sec` int DEFAULT NULL,
  `episode_no` int DEFAULT NULL COMMENT '集序号',
  `sort` int NOT NULL DEFAULT '0',
  `is_entry` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `is_interactive` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '互动节点',
  `choice_trigger_sec` double DEFAULT NULL COMMENT '分支弹出时刻(秒)',
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `review_status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT 'pending/approved/rejected',
  `reject_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核拒绝原因',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`node_id`),
  KEY `idx_dvn_drama` (`drama_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='剧情视频节点';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_video_node`
--

LOCK TABLES `drama_video_node` WRITE;
/*!40000 ALTER TABLE `drama_video_node` DISABLE KEYS */;
INSERT INTO `drama_video_node` VALUES (1,1,NULL,'第1集-意外觉醒','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n1/400/225',NULL,120,1,1,'1','0',NULL,'published','approved',NULL,NULL,NULL),(2,1,NULL,'第2集-选择时刻','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n2/400/225',NULL,120,2,1,'0','1',30,'published','approved',NULL,NULL,NULL),(3,1,NULL,'第3集-暗流涌动','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n3/400/225',NULL,120,3,2,'0','1',30,'published','approved',NULL,NULL,NULL),(4,1,NULL,'第4集-结局','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n4/400/225',NULL,120,4,3,'0','0',NULL,'published','approved',NULL,NULL,NULL),(5,2,NULL,'第1集-穿越之初','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n5/400/225',NULL,120,1,1,'1','0',NULL,'published','approved',NULL,NULL,NULL),(6,2,NULL,'第2集-宫廷初入','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n6/400/225',NULL,120,2,1,'0','1',30,'published','approved',NULL,NULL,NULL),(7,2,NULL,'第3集-权谋抉择','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n7/400/225',NULL,120,3,2,'0','1',30,'published','approved',NULL,NULL,NULL),(8,2,NULL,'第4集-大结局','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n8/400/225',NULL,120,4,3,'0','0',NULL,'published','approved',NULL,NULL,NULL),(9,3,NULL,'第1集-合租开始','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n9/400/225',NULL,120,1,1,'1','0',NULL,'published','approved',NULL,NULL,NULL),(10,3,NULL,'第2集-鸡飞狗跳','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n10/400/225',NULL,120,2,1,'0','1',30,'published','approved',NULL,NULL,NULL),(11,3,NULL,'第3集-圆满结局','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n11/400/225',NULL,120,3,2,'0','0',NULL,'published','approved',NULL,NULL,NULL),(12,4,NULL,'第1集-意外重生','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n12/400/225',NULL,120,1,1,'1','0',NULL,'published','approved',NULL,NULL,NULL),(13,4,NULL,'第2集-命运交叉','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n13/400/225',NULL,120,2,1,'0','1',30,'published','approved',NULL,NULL,NULL),(14,4,NULL,'第3集-大结局','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n14/400/225',NULL,120,3,2,'0','0',NULL,'published','approved',NULL,NULL,NULL),(15,5,NULL,'第1集-入职第一天','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n15/400/225',NULL,120,1,1,'1','0',NULL,'published','approved',NULL,NULL,NULL),(16,5,NULL,'第2集-转正之争','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n16/400/225',NULL,120,2,1,'0','1',30,'published','approved',NULL,NULL,NULL),(17,5,NULL,'第3集-职场巅峰','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n17/400/225',NULL,120,3,2,'0','0',NULL,'published','approved',NULL,NULL,NULL),(18,6,NULL,'第1集-相遇','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n18/400/225',NULL,120,1,1,'1','0',NULL,'published','approved',NULL,NULL,NULL),(19,6,NULL,'第2集-选择','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n19/400/225',NULL,120,2,1,'0','1',30,'published','approved',NULL,NULL,NULL),(20,6,NULL,'第3集-深入','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n20/400/225',NULL,120,3,2,'0','1',30,'published','approved',NULL,NULL,NULL),(21,6,NULL,'第4集-告别','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n21/400/225',NULL,120,4,3,'0','0',NULL,'published','approved',NULL,NULL,NULL);
/*!40000 ALTER TABLE `drama_video_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_video_review`
--

DROP TABLE IF EXISTS `drama_video_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_video_review` (
  `review_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `node_id` bigint DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `admin_remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `audit_time` datetime DEFAULT NULL,
  PRIMARY KEY (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户评价审核';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_video_review`
--

LOCK TABLES `drama_video_review` WRITE;
/*!40000 ALTER TABLE `drama_video_review` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_video_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `config_id` int NOT NULL AUTO_INCREMENT COMMENT '参数主键',
  `config_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '参数名称',
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '参数键名',
  `config_value` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '参数键值',
  `config_type` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '系统内置（Y是 N否）',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='参数配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dept`
--

DROP TABLE IF EXISTS `sys_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dept` (
  `dept_id` bigint NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `parent_id` bigint DEFAULT '0' COMMENT '父部门id',
  `ancestors` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '祖级列表',
  `dept_name` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '部门名称',
  `order_num` int DEFAULT '0' COMMENT '显示顺序',
  `leader` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '负责人',
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系电话',
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '部门状态（0正常 1停用）',
  `del_flag` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='部门表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dept`
--

LOCK TABLES `sys_dept` WRITE;
/*!40000 ALTER TABLE `sys_dept` DISABLE KEYS */;
INSERT INTO `sys_dept` VALUES (100,0,'0','总公司',0,'admin','13800000000','admin@example.com','0','0','admin','2026-05-22 09:30:18','\'\'',NULL);
/*!40000 ALTER TABLE `sys_dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict_data`
--

DROP TABLE IF EXISTS `sys_dict_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict_data` (
  `dict_code` bigint NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `dict_sort` int DEFAULT '0' COMMENT '字典排序',
  `dict_label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '字典标签',
  `dict_value` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '字典键值',
  `dict_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '字典类型',
  `css_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='字典数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict_data`
--

LOCK TABLES `sys_dict_data` WRITE;
/*!40000 ALTER TABLE `sys_dict_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_dict_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict_type`
--

DROP TABLE IF EXISTS `sys_dict_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict_type` (
  `dict_id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '字典名称',
  `dict_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '字典类型',
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`),
  UNIQUE KEY `dict_type` (`dict_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='字典类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict_type`
--

LOCK TABLES `sys_dict_type` WRITE;
/*!40000 ALTER TABLE `sys_dict_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_dict_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_job`
--

DROP TABLE IF EXISTS `sys_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_job` (
  `job_id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `job_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '''''' COMMENT '任务名称',
  `job_group` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default' COMMENT '任务组名',
  `job_executor` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'default' COMMENT '任务执行器',
  `invoke_target` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '调用目标字符串',
  `job_args` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '位置参数',
  `job_kwargs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '关键字参数',
  `cron_expression` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT 'cron执行表达式',
  `misfire_policy` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '3' COMMENT '计划执行错误策略（1立即执行 2执行一次 3放弃执行）',
  `concurrent` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '1' COMMENT '是否并发执行（0允许 1禁止）',
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '状态（0正常 1暂停）',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '备注信息',
  PRIMARY KEY (`job_id`,`job_name`,`job_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='定时任务调度表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_job`
--

LOCK TABLES `sys_job` WRITE;
/*!40000 ALTER TABLE `sys_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_job_log`
--

DROP TABLE IF EXISTS `sys_job_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_job_log` (
  `job_log_id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务日志ID',
  `job_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '任务名称',
  `job_group` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '任务组名',
  `job_executor` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '任务执行器',
  `invoke_target` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '调用目标字符串',
  `job_args` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '位置参数',
  `job_kwargs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '关键字参数',
  `job_trigger` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '任务触发器',
  `job_message` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '日志信息',
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '执行状态（0正常 1失败）',
  `exception_info` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '异常信息',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='定时任务调度日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_job_log`
--

LOCK TABLES `sys_job_log` WRITE;
/*!40000 ALTER TABLE `sys_job_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_job_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_logininfor`
--

DROP TABLE IF EXISTS `sys_logininfor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_logininfor` (
  `info_id` bigint NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '用户账号',
  `ipaddr` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '登录IP地址',
  `login_location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '登录地点',
  `browser` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '浏览器类型',
  `os` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '操作系统',
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '提示消息',
  `login_time` datetime DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`info_id`),
  KEY `idx_sys_logininfor_lt` (`login_time`),
  KEY `idx_sys_logininfor_s` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统访问记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_logininfor`
--

LOCK TABLES `sys_logininfor` WRITE;
/*!40000 ALTER TABLE `sys_logininfor` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_logininfor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_menu`
--

DROP TABLE IF EXISTS `sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_menu` (
  `menu_id` bigint NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(50) NOT NULL,
  `parent_id` bigint DEFAULT '0',
  `order_num` int DEFAULT '0',
  `path` varchar(200) DEFAULT '',
  `component` varchar(255) DEFAULT NULL,
  `query` varchar(255) DEFAULT NULL,
  `route_name` varchar(50) DEFAULT '',
  `is_frame` int DEFAULT '1',
  `is_cache` int DEFAULT '0',
  `menu_type` char(1) DEFAULT NULL,
  `visible` char(1) DEFAULT '0',
  `status` char(1) DEFAULT '0',
  `perms` varchar(100) DEFAULT NULL,
  `icon` varchar(100) DEFAULT '#',
  `create_by` varchar(64) DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  `update_by` varchar(64) DEFAULT '',
  `update_time` datetime DEFAULT NULL,
  `remark` varchar(500) DEFAULT '',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_menu`
--

LOCK TABLES `sys_menu` WRITE;
/*!40000 ALTER TABLE `sys_menu` DISABLE KEYS */;
INSERT INTO `sys_menu` VALUES (1,'系统管理',0,1,'system',NULL,'','',1,0,'M','0','0','','system','admin','2026-05-22 09:34:48','',NULL,'系统管理目录'),(2,'系统监控',0,2,'monitor',NULL,'','',1,0,'M','0','0','','monitor','admin','2026-05-22 09:34:48','',NULL,'系统监控目录'),(3,'系统工具',0,3,'tool',NULL,'','',1,0,'M','0','0','','tool','admin','2026-05-22 09:34:48','',NULL,'系统工具目录'),(4,'AI 管理',0,4,'ai',NULL,'','',1,0,'M','0','0','','ai-manage','admin','2026-05-22 09:34:48','',NULL,'AI 管理目录'),(100,'用户管理',1,1,'user','system/user/index','','',1,0,'C','0','0','system:user:list','user','admin','2026-05-22 09:34:48','',NULL,'用户管理菜单'),(101,'角色管理',1,2,'role','system/role/index','','',1,0,'C','0','0','system:role:list','peoples','admin','2026-05-22 09:34:48','',NULL,'角色管理菜单'),(102,'菜单管理',1,3,'menu','system/menu/index','','',1,0,'C','0','0','system:menu:list','tree-table','admin','2026-05-22 09:34:48','',NULL,'菜单管理菜单'),(103,'部门管理',1,4,'dept','system/dept/index','','',1,0,'C','0','0','system:dept:list','tree','admin','2026-05-22 09:34:48','',NULL,'部门管理菜单'),(104,'岗位管理',1,5,'post','system/post/index','','',1,0,'C','0','0','system:post:list','post','admin','2026-05-22 09:34:48','',NULL,'岗位管理菜单'),(105,'字典管理',1,6,'dict','system/dict/index','','',1,0,'C','0','0','system:dict:list','dict','admin','2026-05-22 09:34:48','',NULL,'字典管理菜单'),(106,'参数设置',1,7,'config','system/config/index','','',1,0,'C','0','0','system:config:list','edit','admin','2026-05-22 09:34:48','',NULL,'参数设置菜单'),(107,'通知公告',1,8,'notice','system/notice/index','','',1,0,'C','0','0','system:notice:list','message','admin','2026-05-22 09:34:48','',NULL,'通知公告菜单'),(108,'日志管理',1,9,'log','','','',1,0,'M','0','0','','log','admin','2026-05-22 09:34:48','',NULL,'日志管理菜单'),(109,'在线用户',2,1,'online','monitor/online/index','','',1,0,'C','0','0','monitor:online:list','online','admin','2026-05-22 09:34:48','',NULL,'在线用户菜单'),(110,'定时任务',2,2,'job','monitor/job/index','','',1,0,'C','0','0','monitor:job:list','job','admin','2026-05-22 09:34:48','',NULL,'定时任务菜单'),(111,'数据监控',2,3,'druid','monitor/druid/index','','',1,0,'C','0','0','monitor:druid:list','druid','admin','2026-05-22 09:34:48','',NULL,'数据监控菜单'),(112,'服务监控',2,4,'server','monitor/server/index','','',1,0,'C','0','0','monitor:server:list','server','admin','2026-05-22 09:34:48','',NULL,'服务监控菜单'),(500,'短剧管理',4,1,'drama','ai/drama/index','','',1,0,'C','0','0','ai:drama:list','video','admin','2026-05-22 09:34:48','',NULL,'短剧管理菜单'),(501,'剧目管理',500,1,'index','ai/drama/index','','',1,0,'C','0','0','ai:drama:list','video','admin','2026-05-22 09:34:48','',NULL,NULL),(502,'广告管理',4,2,'ad','ai/ad/index','','',1,0,'C','0','0','ai:ad:list','shopping','admin','2026-05-22 09:34:48','',NULL,'广告管理菜单');
/*!40000 ALTER TABLE `sys_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_oper_log`
--

DROP TABLE IF EXISTS `sys_oper_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_oper_log` (
  `oper_id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '模块标题',
  `business_type` int DEFAULT '0' COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '方法名称',
  `request_method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '请求方式',
  `operator_type` int DEFAULT '0' COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '操作人员',
  `dept_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '部门名称',
  `oper_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '请求URL',
  `oper_ip` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '主机地址',
  `oper_location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '操作地点',
  `oper_param` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '请求参数',
  `json_result` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '返回参数',
  `status` int DEFAULT '0' COMMENT '操作状态（0正常 1异常）',
  `error_msg` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '错误消息',
  `oper_time` datetime DEFAULT NULL COMMENT '操作时间',
  `cost_time` bigint DEFAULT '0' COMMENT '消耗时间',
  PRIMARY KEY (`oper_id`),
  KEY `idx_sys_oper_log_s` (`status`),
  KEY `idx_sys_oper_log_ot` (`oper_time`),
  KEY `idx_sys_oper_log_bt` (`business_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作日志记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_oper_log`
--

LOCK TABLES `sys_oper_log` WRITE;
/*!40000 ALTER TABLE `sys_oper_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_oper_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_post`
--

DROP TABLE IF EXISTS `sys_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_post` (
  `post_id` bigint NOT NULL AUTO_INCREMENT,
  `post_code` varchar(64) NOT NULL,
  `post_name` varchar(50) NOT NULL,
  `post_sort` int NOT NULL,
  `status` char(1) NOT NULL DEFAULT '0',
  `create_by` varchar(64) DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  `update_by` varchar(64) DEFAULT '',
  `update_time` datetime DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_post`
--

LOCK TABLES `sys_post` WRITE;
/*!40000 ALTER TABLE `sys_post` DISABLE KEYS */;
INSERT INTO `sys_post` VALUES (1,'ceo','董事长',1,'0','admin','2026-05-22 09:32:24','',NULL,''),(2,'se','项目经理',2,'0','admin','2026-05-22 09:32:24','',NULL,''),(3,'hr','人力资源',3,'0','admin','2026-05-22 09:32:24','',NULL,''),(4,'user','普通员工',4,'0','admin','2026-05-22 09:32:24','',NULL,'');
/*!40000 ALTER TABLE `sys_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role` (
  `role_id` bigint NOT NULL AUTO_INCREMENT,
  `role_name` varchar(30) NOT NULL,
  `role_key` varchar(100) NOT NULL,
  `role_sort` int NOT NULL,
  `data_scope` char(1) DEFAULT '1',
  `menu_check_strictly` tinyint(1) DEFAULT '1',
  `dept_check_strictly` tinyint(1) DEFAULT '1',
  `status` char(1) NOT NULL DEFAULT '0',
  `del_flag` char(1) DEFAULT '0',
  `create_by` varchar(64) DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  `update_by` varchar(64) DEFAULT '',
  `update_time` datetime DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES (1,'超级管理员','admin',1,'1',1,1,'0','0','admin','2026-05-22 09:32:25','',NULL,'超级管理员'),(2,'普通角色','common',2,'2',1,1,'0','0','admin','2026-05-22 09:32:25','',NULL,'普通角色');
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_dept`
--

DROP TABLE IF EXISTS `sys_role_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_dept` (
  `role_id` bigint NOT NULL,
  `dept_id` bigint NOT NULL,
  PRIMARY KEY (`role_id`,`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_dept`
--

LOCK TABLES `sys_role_dept` WRITE;
/*!40000 ALTER TABLE `sys_role_dept` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_role_dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_menu`
--

DROP TABLE IF EXISTS `sys_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_menu` (
  `role_id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  PRIMARY KEY (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_menu`
--

LOCK TABLES `sys_role_menu` WRITE;
/*!40000 ALTER TABLE `sys_role_menu` DISABLE KEYS */;
INSERT INTO `sys_role_menu` VALUES (1,1),(1,2),(1,3),(1,4),(1,100),(1,101),(1,102),(1,103),(1,104),(1,105),(1,106),(1,107),(1,108),(1,109),(1,110),(1,111),(1,112),(1,500),(1,501),(1,502);
/*!40000 ALTER TABLE `sys_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `dept_id` bigint DEFAULT NULL COMMENT '部门ID',
  `user_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户账号',
  `nick_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户昵称',
  `user_type` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT '00' COMMENT '用户类型（00系统用户）',
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '用户邮箱',
  `phonenumber` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '手机号码',
  `sex` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '头像地址',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '密码',
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `del_flag` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '最后登录IP',
  `login_date` datetime DEFAULT NULL COMMENT '最后登录时间',
  `pwd_update_date` datetime DEFAULT NULL COMMENT '密码最后更新时间',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '''''' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (1,100,'admin','系统管理员','00','admin@example.com','13800000000','1','','$2b$12$ex0fGyFvrNcIGVcN/qUvbe2./RYAY3fowkK3a0DoDnMIhXkQPwwwO','0','0','127.0.0.1','2026-05-22 10:29:06','2026-05-22 09:29:32','admin','2026-05-22 09:29:32','\'\'',NULL,NULL);
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_post`
--

DROP TABLE IF EXISTS `sys_user_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_post` (
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `post_id` bigint NOT NULL COMMENT '岗位ID',
  PRIMARY KEY (`user_id`,`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户与岗位关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_post`
--

LOCK TABLES `sys_user_post` WRITE;
/*!40000 ALTER TABLE `sys_user_post` DISABLE KEYS */;
INSERT INTO `sys_user_post` VALUES (1,1);
/*!40000 ALTER TABLE `sys_user_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_role`
--

DROP TABLE IF EXISTS `sys_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_role` (
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `role_id` bigint NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户和角色关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_role`
--

LOCK TABLES `sys_user_role` WRITE;
/*!40000 ALTER TABLE `sys_user_role` DISABLE KEYS */;
INSERT INTO `sys_user_role` VALUES (1,1);
/*!40000 ALTER TABLE `sys_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ai_video'
--

--
-- Dumping routines for database 'ai_video'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-23  3:00:15
