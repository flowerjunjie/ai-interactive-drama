-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: ai_video
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `drama`
--

DROP TABLE IF EXISTS `drama`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama` (
  `drama_id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `drama_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comic_drama',
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `sort` int NOT NULL DEFAULT '0',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `update_time` datetime DEFAULT NULL,
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签 JSON 或逗号分隔',
  `heat` int NOT NULL DEFAULT '0' COMMENT '热度',
  PRIMARY KEY (`drama_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短剧';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama`
--

LOCK TABLES `drama` WRITE;
/*!40000 ALTER TABLE `drama` DISABLE KEYS */;
INSERT INTO `drama` VALUES (1,'都市狂想','https://picsum.photos/seed/d1/400/600','都市青年意外获得读心术，在职场与情感中层层闯关','urban','published',10,'system',NULL,'',NULL,NULL,'都市异能职场',8500),(2,'古风奇缘','https://picsum.photos/seed/d2/400/600','穿越古代成为王妃，宫廷权谋中寻找真爱','costume','published',9,'system',NULL,'',NULL,NULL,'古风穿越宫斗',6200),(3,'浪漫满屋','https://picsum.photos/seed/d3/400/600','欢喜冤家合租一屋檐下，日久生情的爆笑爱情','romance','published',8,'system',NULL,'',NULL,NULL,'甜宠合租都市',9100);
/*!40000 ALTER TABLE `drama` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_ad`
--

DROP TABLE IF EXISTS `drama_ad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_ad` (
  `ad_id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `media_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'image' COMMENT 'image/video',
  `media_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主素材',
  `image_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '兼容旧字段',
  `cover_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '视频封面',
  `link_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slot_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'feed',
  `weight` int NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `impression_count` bigint NOT NULL DEFAULT '0',
  `click_count` bigint NOT NULL DEFAULT '0',
  `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短剧广告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_ad`
--

LOCK TABLES `drama_ad` WRITE;
/*!40000 ALTER TABLE `drama_ad` DISABLE KEYS */;
INSERT INTO `drama_ad` VALUES (1,'热播推荐','image','https://picsum.photos/seed/ad1/800/400',NULL,NULL,NULL,'feed',10,NULL,NULL,0,0,'0',NULL),(2,'限时活动','image','https://picsum.photos/seed/ad2/800/400',NULL,NULL,NULL,'pause',8,NULL,NULL,0,0,'0',NULL);
/*!40000 ALTER TABLE `drama_ad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_app_user`
--

DROP TABLE IF EXISTS `drama_app_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_app_user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '登录账号',
  `nick_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '昵称',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码hash',
  `avatar` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '头像',
  `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '0正常1停用',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uk_drama_app_user_name` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短剧 C 端用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_app_user`
--

LOCK TABLES `drama_app_user` WRITE;
/*!40000 ALTER TABLE `drama_app_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_app_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_comment`
--

DROP TABLE IF EXISTS `drama_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_comment` (
  `comment_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `node_id` bigint DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `idx_dc_drama` (`drama_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_comment`
--

LOCK TABLES `drama_comment` WRITE;
/*!40000 ALTER TABLE `drama_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_upload_file`
--

DROP TABLE IF EXISTS `drama_upload_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_upload_file` (
  `file_id` bigint NOT NULL AUTO_INCREMENT,
  `object_key` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bucket` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size_bytes` bigint DEFAULT NULL,
  `drama_id` bigint DEFAULT NULL,
  `node_id` bigint DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='上传文件记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_upload_file`
--

LOCK TABLES `drama_upload_file` WRITE;
/*!40000 ALTER TABLE `drama_upload_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_upload_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_user_choice_log`
--

DROP TABLE IF EXISTS `drama_user_choice_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_user_choice_log` (
  `log_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `from_node_id` bigint DEFAULT NULL,
  `choice_id` bigint NOT NULL,
  `to_node_id` bigint NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分支选择记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_user_choice_log`
--

LOCK TABLES `drama_user_choice_log` WRITE;
/*!40000 ALTER TABLE `drama_user_choice_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_user_choice_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_user_favorite`
--

DROP TABLE IF EXISTS `drama_user_favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_user_favorite` (
  `fav_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`fav_id`),
  UNIQUE KEY `uq_drama_fav_user_drama` (`app_user_id`,`drama_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='收藏';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_user_favorite`
--

LOCK TABLES `drama_user_favorite` WRITE;
/*!40000 ALTER TABLE `drama_user_favorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_user_favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_user_like`
--

DROP TABLE IF EXISTS `drama_user_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_user_like` (
  `like_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `target_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`like_id`),
  UNIQUE KEY `uq_drama_like_target` (`app_user_id`,`target_type`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='点赞';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_user_like`
--

LOCK TABLES `drama_user_like` WRITE;
/*!40000 ALTER TABLE `drama_user_like` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_user_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_user_watch_history`
--

DROP TABLE IF EXISTS `drama_user_watch_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_user_watch_history` (
  `history_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `node_id` bigint DEFAULT NULL,
  `progress_sec` int NOT NULL DEFAULT '0',
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`history_id`),
  UNIQUE KEY `uq_drama_watch_user_drama` (`app_user_id`,`drama_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='观看进度';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_user_watch_history`
--

LOCK TABLES `drama_user_watch_history` WRITE;
/*!40000 ALTER TABLE `drama_user_watch_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_user_watch_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_video_choice`
--

DROP TABLE IF EXISTS `drama_video_choice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_video_choice` (
  `choice_id` bigint NOT NULL AUTO_INCREMENT,
  `node_id` bigint NOT NULL,
  `choice_code` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '选项编码 A/B/C',
  `label` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_node_id` bigint NOT NULL,
  `sort` int NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`choice_id`),
  KEY `idx_dvc_node` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分支选项';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_video_choice`
--

LOCK TABLES `drama_video_choice` WRITE;
/*!40000 ALTER TABLE `drama_video_choice` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_video_choice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_video_node`
--

DROP TABLE IF EXISTS `drama_video_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_video_node` (
  `node_id` bigint NOT NULL AUTO_INCREMENT,
  `drama_id` bigint NOT NULL,
  `parent_node_id` bigint DEFAULT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tos_key` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'TOS 对象键',
  `duration_sec` int DEFAULT NULL,
  `episode_no` int DEFAULT NULL COMMENT '集序号',
  `sort` int NOT NULL DEFAULT '0',
  `is_entry` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `is_interactive` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '互动节点',
  `choice_trigger_sec` double DEFAULT NULL COMMENT '分支弹出时刻(秒)',
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `review_status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT 'pending/approved/rejected',
  `reject_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核拒绝原因',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`node_id`),
  KEY `idx_dvn_drama` (`drama_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='剧情视频节点';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_video_node`
--

LOCK TABLES `drama_video_node` WRITE;
/*!40000 ALTER TABLE `drama_video_node` DISABLE KEYS */;
INSERT INTO `drama_video_node` VALUES (1,1,NULL,'第1集-意外觉醒','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n1/400/225',NULL,NULL,NULL,1,'1','0',NULL,'draft','approved',NULL,NULL,NULL),(2,1,NULL,'第2集-职场暗流','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n2/400/225',NULL,NULL,NULL,2,'0','0',NULL,'draft','approved',NULL,NULL,NULL),(3,2,NULL,'第1集-穿越之初','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n3/400/225',NULL,NULL,NULL,1,'1','0',NULL,'draft','approved',NULL,NULL,NULL),(4,2,NULL,'第2集-宫廷初入','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n4/400/225',NULL,NULL,NULL,2,'0','0',NULL,'draft','approved',NULL,NULL,NULL),(5,3,NULL,'第1集-合租开始','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n5/400/225',NULL,NULL,NULL,1,'1','0',NULL,'draft','approved',NULL,NULL,NULL),(6,3,NULL,'第2集-鸡飞狗跳','https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8','https://picsum.photos/seed/n6/400/225',NULL,NULL,NULL,2,'0','0',NULL,'draft','approved',NULL,NULL,NULL);
/*!40000 ALTER TABLE `drama_video_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drama_video_review`
--

DROP TABLE IF EXISTS `drama_video_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drama_video_review` (
  `review_id` bigint NOT NULL AUTO_INCREMENT,
  `app_user_id` bigint NOT NULL,
  `drama_id` bigint NOT NULL,
  `node_id` bigint DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `admin_remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `audit_time` datetime DEFAULT NULL,
  PRIMARY KEY (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户评价审核';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drama_video_review`
--

LOCK TABLES `drama_video_review` WRITE;
/*!40000 ALTER TABLE `drama_video_review` DISABLE KEYS */;
/*!40000 ALTER TABLE `drama_video_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ai_video'
--

--
-- Dumping routines for database 'ai_video'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-21  8:01:54
